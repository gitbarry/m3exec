<?php
    $town       = "Frimley";
    $url_town   = strtolower($town);
    $company    = "M3 Exec Cars";
    $base_url   = "http://www.m3exec.co.uk";
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>Taxis in <? echo $town; ?></title>
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta name="description" content="Professional, reliable executive car and taxi service covering <? echo $town; ?>. Call or email today" />
    <meta name="keywords" content="taxi, taxis, <? echo $town; ?>" />
    <link href="/stylesheets/screen.css" media="screen, projection" rel="stylesheet" type="text/css" />
    <link href="/stylesheets/print.css" media="print" rel="stylesheet" type="text/css" />
    <!--[if IE]>
    <link href="/stylesheets/ie.css" media="screen, projection" rel="stylesheet" type="text/css" />
    <![endif]-->
</head>
<body>
<header>
    <div class="inner">
        <div class="logo"><img src="images/taxis-in-fleet.jpg" alt="Taxis in <? echo $town; ?>" /></div>
        <div class="info">
            <h1><? echo $town; ?> Taxis</h1>
            <h3>For taxis in <? echo $town; ?></h3>
            <h3><a href="mailto:m3execcars@aol.co.uk">M3execcars@aol.co.uk</a></h3>
        </div>
    </div>
</header>
<div class="content">
<div class="container">
    <div class="inner">
        <div class="top">
        <h2>Professional, reliable executive car and taxi service covering <? echo $town; ?>. <span>Call or email today</span></h2>
            <div class="desktop">
                <h4 class="call"><span>01276 24444</span></h4>
                <a href="<? echo $base_url; ?>/book-online" class="button" title="Book your <? echo $town; ?> taxi here">Book your <? echo $town; ?> taxi here</a>
            </div>

        </div>

        <p>From corporate bookings to airport transfers <? echo $company; ?> is the <? echo $town; ?> taxi of choice. With a range of 4 and 6 seater executive cars, our professional and reliable drivers will take you door-to-door on time, every time. From corporate and private hire services to holiday transfers to all major UK airports, we offer an impeccable taxi service taking the hassle out of your travel arrangements.</p>
        <p>Our dedicated team are always at the end of the phone to help so give them a call for a free, no obligation quote. Alternatively use our simple online booking system where you can book and pay online. We accept all major credit cards.</p>
        <p>We pride ourselves on providing customers in <? echo $town; ?> with a consistently reliable transfer service, 24 hours a day, 7 days a week. Call us today!</p>
        <div class="cards">
            <img src="images/cards.png" alt="All major cards accepted" />
        </div>
    </div>
</div>
</div>
<footer>
    <div class="inner">
        <h4><a href="<? echo $base_url; ?>" alt="Taxis in <? echo $town; ?>" title="Taxis in <? echo $town; ?>">Taxis in <? echo $town; ?> and surrounding areas</a></h4>
        <div class="footer-links">
            <span>See also: </span>
            <a href="http://humphriescars.co.uk" title="Taxis in <? echo $town; ?> - Humphries Cars" target="_blank">Humphries Cars</a>
            <a href="http://ndhprivatehire.com" title="Taxis in <? echo $town; ?> - NDH Private Hire" target="_blank">NDH Private Hire</a>
            <a href="http://www.matrixtaxis.co.uk" title="Taxis in <? echo $town; ?> - Matrix Taxis" target="_blank">Matrix Taxis</a>
        </div>
    </div>
</footer>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-61084492-1', 'auto');
  ga('send', 'pageview');

</script>
</body>
</html>